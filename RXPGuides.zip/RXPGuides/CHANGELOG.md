# RestedXP Guides

## [v4.11.26](https://github.com/RestedXP/RXPGuides/tree/v4.11.26) (2026-10-17)
[Full Changelog](https://github.com/RestedXP/RXPGuides/compare/v4.11.25...v4.11.26) [Previous Releases](https://github.com/RestedXP/RXPGuides/releases)

- Improved dungeon selection prompt  
